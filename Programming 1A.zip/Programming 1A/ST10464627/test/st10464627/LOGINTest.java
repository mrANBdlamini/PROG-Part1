/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java
 */

package st10464627;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Unit tests for the MAIN class.
 *
 * @author Asimt
 */
public class LOGINTest {

    // Test valid username 
    @Test
    public void testValidUserName() {
        String userName = "+27821234567";

        boolean result = MAIN.checkUserName(userName);

        assertTrue(result);
    }

    // Test invalid username
    @Test
    public void testInvalidUserName() {
        String userName = "user_1";

        boolean result = MAIN.checkUserName(userName);

        assertFalse(result);
    }

    // Test empty username
    @Test
    public void testEmptyUserName() {
        String userName = "";

        boolean result = MAIN.checkUserName(userName);

        assertFalse(result);
    }

    // Test valid South African cellphone number
    @Test
    public void testValidCellPhoneNumber() {
        String cellPhoneNumber = "+27821234567";

        boolean result = MAIN.checkCellPhoneNumber(cellPhoneNumber);

        assertTrue(result);
    }

    // Test invalid cellphone number
    @Test
    public void testInvalidCellPhoneNumber() {
        String cellPhoneNumber = "0821234567";

        boolean result = MAIN.checkCellPhoneNumber(cellPhoneNumber);

        assertFalse(result);
    }

    // Test cellphone number with incorrect length
    @Test
    public void testIncorrectCellPhoneNumber() {
        String cellPhoneNumber = "+2782123456";

        boolean result = MAIN.checkCellPhoneNumber(cellPhoneNumber);

        assertFalse(result);
    }

    // Test valid password
    @Test
    public void testValidPassword() {
        String password = "Password1!";

        boolean result = MAIN.checkPassword(password);

        assertTrue(result);
    }

    // Test password without capital letter
    @Test
    public void testPasswordWithoutCapitalLetter() {
        String password = "password1!";

        boolean result = MAIN.checkPassword(password);

        assertFalse(result);
    }

    // Test password without a number
    @Test
    public void testPasswordWithoutNumber() {
        String password = "Password!";

        boolean result = MAIN.checkPassword(password);

        assertFalse(result);
    }

    // Test password without a special character
    @Test
    public void testPasswordWithoutSpecialCharacter() {
        String password = "Password1";

        boolean result = MAIN.checkPassword(password);

        assertFalse(result);
    }

    // Test password shorter than 8 characters
    @Test
    public void testShortPassword() {
        String password = "Pass1!";

        boolean result = MAIN.checkPassword(password);

        assertFalse(result);
    }

    // Test empty password
    @Test
    public void testEmptyPassword() {
        String password = "";

        boolean result = MAIN.checkPassword(password);

        assertFalse(result);
    }
}