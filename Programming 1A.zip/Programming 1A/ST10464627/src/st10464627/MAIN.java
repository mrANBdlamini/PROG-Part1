/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10464627;

import java.util.Scanner;
import java.util.regex.Pattern;

/**
 *
 * @author Asimt
 */
public class MAIN {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner input = new Scanner(System.in); 
            
    // Variables
        String name;
        String surname;
        String userName;
        String cellPhoneNumber;
        String password;

    // Prompt the User to enter their Name
        System.out.println("Enter your name:");
        name = input.nextLine();

    // Prompt the User to enter their Surname
        System.out.println("Enter your Surname:");
        surname = input.nextLine();

    // Prompt the User to enter their Username using a while loop
        while (true) {

            System.out.println("Enter your username:");
            userName = input.nextLine();

            if (checkUserName(userName)) {
                System.out.println("Username successfully captured");
                break;
            } else {
                System.out.println("Username is not correctly formatted.");
                System.out.println("Please ensure that your username contains");
                System.out.println("an underscore and is no more than 5 characters.");
            }
        }

    // Prompt the User to enter their CellPhone Number using a while loop
        while (true) {

            System.out.println("Enter your CellPhone Number:");
            cellPhoneNumber = input.nextLine();

            if (checkCellPhoneNumber(cellPhoneNumber)) {
                System.out.println("CellPhone Number successfully entered");
                break;
            } else {
                System.out.println("Your CellPhone Number is incorrectly entered.");
                System.out.println("Your CellPhone Number must use the international");
                System.out.println("South African format, for example: +27821234567");
            }
        }

    // Prompt the User to enter their Password using a while loop
        while (true) {

            System.out.println("Enter your Password:");
            password = input.nextLine();

            if (checkPassword(password)) {
                System.out.println("Password successfully entered");
                break;
            } else {
                System.out.println("Your password is incorrect.");
                System.out.println("Your password must have at least 8 characters,");
                System.out.println("a capital letter, a number and a special character.");
            }
        }

    // Registration successful
        System.out.println();
        System.out.println("You have registered successfully!");
        System.out.println("Welcome " + name + " " + surname);

        input.close();
    }

    // Method to check username
    public static boolean checkUserName(String userName) {

        if (userName == null) {
            return false;
        }
    // Username must contain an underscore
    // and must not be more than 5 characters
        String regex = "\\+27[0-9]{9}$";

        return userName.length() <= 5 && Pattern.matches(regex, userName);
    }

    // Method to check cellphone number
    public static boolean checkCellPhoneNumber(String cellPhoneNumber) {

        if (cellPhoneNumber == null) {
            return false;
        }

    // South African international format
        String regex = "\\+27[0-9]{9}$";

        return Pattern.matches(regex, cellPhoneNumber);
    }

    // Method to check password
    public static boolean checkPassword(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasSpecialCharacter = false;
        boolean hasNumber = false;

        for (int i = 0; i < password.length(); i++) {

            char chPassword = password.charAt(i);

            if (Character.isUpperCase(chPassword)) {
                hasCapitalLetter = true;
            }

            if (Character.isDigit(chPassword)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(chPassword)) {
                hasSpecialCharacter = true;
            }
        }

        return hasCapitalLetter && hasSpecialCharacter && hasNumber;
    }
}    

