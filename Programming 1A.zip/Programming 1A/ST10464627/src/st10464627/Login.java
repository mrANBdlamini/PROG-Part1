/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java
 */

package st10464627;

public class Login {

    private String registeredUserName;
    private String registeredPassword;
    private String name;
    private String surname;

    // Register the user's details
    public void registerUser(String userName, String password,
                             String name, String surname) {

        this.registeredUserName = userName;
        this.registeredPassword = password;
        this.name = name;
        this.surname = surname;
    }

    // Check if username and password are correct
    public boolean loginUser(String userName, String password) {

        if (userName == null || password == null) {
            return false;
        }

        return userName.equals(registeredUserName)
                && password.equals(registeredPassword);
    }

    // Get login message
    public String returnLoginStatus(String userName, String password) {

        if (loginUser(userName, password)) {
            return "Welcome " + name + " " + surname
                    + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Get registered username
    public String getUserName() {
        return registeredUserName;
    }

    // Get registered password
    public String getPassword() {
        return registeredPassword;
    }
}
